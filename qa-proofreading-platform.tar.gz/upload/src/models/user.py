from datetime import datetime
from . import db

class UserGroup(db.Model):
    """用户组模型"""
    __tablename__ = 'user_groups'
    
    id = db.Column(db.String(36), primary_key=True)
    name = db.Column(db.String(100), nullable=False, unique=True)
    description = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # 关系
    users = db.relationship('User', backref='user_group', lazy=True)
    admin_group_bindings = db.relationship('AdminGroupBinding', backref='user_group', lazy=True)
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'user_count': len(self.users)
        }

class AdminGroup(db.Model):
    """管理员组模型"""
    __tablename__ = 'admin_groups'
    
    id = db.Column(db.String(36), primary_key=True)
    name = db.Column(db.String(100), nullable=False, unique=True)
    description = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # 关系
    admins = db.relationship('User', backref='admin_group', lazy=True)
    user_group_bindings = db.relationship('AdminGroupBinding', backref='admin_group', lazy=True)
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'admin_count': len(self.admins),
            'bound_user_groups': [binding.user_group.to_dict() for binding in self.user_group_bindings]
        }

class AdminGroupBinding(db.Model):
    """管理员组与用户组绑定关系"""
    __tablename__ = 'admin_group_bindings'
    
    id = db.Column(db.String(36), primary_key=True)
    admin_group_id = db.Column(db.String(36), db.ForeignKey('admin_groups.id'), nullable=False)
    user_group_id = db.Column(db.String(36), db.ForeignKey('user_groups.id'), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # 唯一约束：一个管理员组只能绑定一个用户组一次
    __table_args__ = (db.UniqueConstraint('admin_group_id', 'user_group_id'),)
    
    def to_dict(self):
        return {
            'id': self.id,
            'admin_group_id': self.admin_group_id,
            'user_group_id': self.user_group_id,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

class User(db.Model):
    __tablename__ = 'users'
    
    id = db.Column(db.String(36), primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    is_admin = db.Column(db.Boolean, default=False)
    user_group_id = db.Column(db.String(36), db.ForeignKey('user_groups.id'), nullable=True)
    admin_group_id = db.Column(db.String(36), db.ForeignKey('admin_groups.id'), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # 关系
    task_assignments = db.relationship('TaskAssignment', backref='user', lazy=True)
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'is_admin': self.is_admin,
            'user_group_id': self.user_group_id,
            'admin_group_id': self.admin_group_id,
            'user_group': self.user_group.to_dict() if self.user_group else None,
            'admin_group': self.admin_group.to_dict() if self.admin_group else None,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }
    
    def can_assign_to_user_group(self, target_user_group_id):
        """检查当前管理员是否可以向指定用户组分配任务"""
        if not self.is_admin or not self.admin_group_id:
            return False
        
        # 检查管理员组是否绑定了目标用户组
        binding = AdminGroupBinding.query.filter_by(
            admin_group_id=self.admin_group_id,
            user_group_id=target_user_group_id
        ).first()
        
        return binding is not None
    
    def get_assignable_users(self):
        """获取当前管理员可以分配任务的用户列表"""
        if not self.is_admin or not self.admin_group_id:
            return []
        
        # 获取管理员组绑定的所有用户组
        bindings = AdminGroupBinding.query.filter_by(admin_group_id=self.admin_group_id).all()
        user_group_ids = [binding.user_group_id for binding in bindings]
        
        # 获取这些用户组中的所有用户
        users = User.query.filter(User.user_group_id.in_(user_group_ids)).all()
        return users

