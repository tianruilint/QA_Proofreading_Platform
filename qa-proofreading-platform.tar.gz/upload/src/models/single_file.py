from datetime import datetime
from . import db

class SingleFileSession(db.Model):
    __tablename__ = 'single_file_sessions'
    
    id = db.Column(db.String(36), primary_key=True)
    file_path = db.Column(db.String(500), nullable=False)
    original_filename = db.Column(db.String(200), nullable=False)
    total_pairs = db.Column(db.Integer, default=0)
    processed_pairs = db.Column(db.Integer, default=0)
    status = db.Column(db.String(20), default='active')  # active, completed, expired
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'file_path': self.file_path,
            'original_filename': self.original_filename,
            'total_pairs': self.total_pairs,
            'processed_pairs': self.processed_pairs,
            'status': self.status,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }

