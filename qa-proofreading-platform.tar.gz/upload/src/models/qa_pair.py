from datetime import datetime
from . import db

class QAPair(db.Model):
    __tablename__ = 'qa_pairs'
    
    id = db.Column(db.String(36), primary_key=True)
    task_id = db.Column(db.String(36), db.ForeignKey('tasks.id'), nullable=True)
    session_id = db.Column(db.String(36), db.ForeignKey('single_file_sessions.id'), nullable=True)
    original_question = db.Column(db.Text, nullable=False)
    original_answer = db.Column(db.Text, nullable=False)
    corrected_question = db.Column(db.Text)
    corrected_answer = db.Column(db.Text)
    status = db.Column(db.String(20), default='pending')  # pending, corrected, reviewed, approved
    corrected_by = db.Column(db.String(36), db.ForeignKey('users.id'), nullable=True)
    reviewed_by = db.Column(db.String(36), db.ForeignKey('users.id'), nullable=True)
    corrected_at = db.Column(db.DateTime)
    reviewed_at = db.Column(db.DateTime)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # 关系
    corrector = db.relationship('User', foreign_keys=[corrected_by], backref='corrected_qa_pairs')
    reviewer = db.relationship('User', foreign_keys=[reviewed_by], backref='reviewed_qa_pairs')
    
    def to_dict(self, include_user_info=False):
        result = {
            'id': self.id,
            'task_id': self.task_id,
            'session_id': self.session_id,
            'original_question': self.original_question,
            'original_answer': self.original_answer,
            'corrected_question': self.corrected_question,
            'corrected_answer': self.corrected_answer,
            'status': self.status,
            'corrected_by': self.corrected_by,
            'reviewed_by': self.reviewed_by,
            'corrected_at': self.corrected_at.isoformat() if self.corrected_at else None,
            'reviewed_at': self.reviewed_at.isoformat() if self.reviewed_at else None,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }
        
        # 包含用户信息用于溯源
        if include_user_info:
            if self.corrector:
                result['corrector_info'] = {
                    'id': self.corrector.id,
                    'name': self.corrector.name,
                    'user_group': self.corrector.user_group.name if self.corrector.user_group else None
                }
            
            if self.reviewer:
                result['reviewer_info'] = {
                    'id': self.reviewer.id,
                    'name': self.reviewer.name,
                    'user_group': self.reviewer.user_group.name if self.reviewer.user_group else None
                }
        
        return result
    
    def get_correction_history(self):
        """获取校对历史信息"""
        history = []
        
        if self.corrected_by and self.corrected_at:
            history.append({
                'action': 'corrected',
                'user_id': self.corrected_by,
                'user_name': self.corrector.name if self.corrector else '未知用户',
                'user_group': self.corrector.user_group.name if self.corrector and self.corrector.user_group else None,
                'timestamp': self.corrected_at.isoformat(),
                'changes': {
                    'question': {
                        'from': self.original_question,
                        'to': self.corrected_question
                    } if self.corrected_question and self.corrected_question != self.original_question else None,
                    'answer': {
                        'from': self.original_answer,
                        'to': self.corrected_answer
                    } if self.corrected_answer and self.corrected_answer != self.original_answer else None
                }
            })
        
        if self.reviewed_by and self.reviewed_at:
            history.append({
                'action': 'reviewed',
                'user_id': self.reviewed_by,
                'user_name': self.reviewer.name if self.reviewer else '未知用户',
                'user_group': self.reviewer.user_group.name if self.reviewer and self.reviewer.user_group else None,
                'timestamp': self.reviewed_at.isoformat()
            })
        
        return sorted(history, key=lambda x: x['timestamp'])

