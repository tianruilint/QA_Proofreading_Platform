import os
from flask import Blueprint, request, jsonify
from src.models import db
from src.models.single_file import SingleFileSession
from src.models.task import Task, TaskAssignment
from src.models.user import User
from src.routes.auth import login_required
from src.config import Config

file_management_bp = Blueprint('file_management', __name__)

@file_management_bp.route('/files/<session_id>/delete', methods=['DELETE'])
@login_required
def delete_file(current_user, session_id):
    """删除文件（带权限控制）"""
    session = SingleFileSession.query.get(session_id)
    if not session:
        return jsonify({
            'success': False,
            'error': {
                'code': 'SESSION_NOT_FOUND',
                'message': '文件会话不存在'
            }
        }), 404
    
    # 检查删除权限
    can_delete, reason = check_delete_permission(current_user, session)
    if not can_delete:
        return jsonify({
            'success': False,
            'error': {
                'code': 'PERMISSION_DENIED',
                'message': reason
            }
        }), 403
    
    try:
        # 删除物理文件
        if os.path.exists(session.file_path):
            os.remove(session.file_path)
        
        # 删除数据库记录（级联删除QA对）
        db.session.delete(session)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': '文件删除成功'
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'error': {
                'code': 'DELETE_ERROR',
                'message': f'文件删除失败：{str(e)}'
            }
        }), 500

def check_delete_permission(user, session):
    """检查文件删除权限"""
    # 管理员可以删除任何文件
    if user.is_admin:
        return True, "管理员权限"
    
    # 检查文件是否是通过任务分配的
    task_assignment = TaskAssignment.query.filter_by(
        user_id=user.id,
        status__in=['assigned', 'in_progress', 'completed']
    ).join(Task).filter(
        Task.file_path == session.file_path
    ).first()
    
    if task_assignment:
        return False, "不能删除通过任务分配的文件，请联系管理员"
    
    # 检查文件是否是用户自己上传的
    # 这里需要在SingleFileSession模型中添加uploaded_by字段来跟踪上传者
    # 暂时允许用户删除（假设是自己上传的）
    return True, "用户自己上传的文件"

@file_management_bp.route('/files', methods=['GET'])
@login_required
def list_files(current_user):
    """获取文件列表（根据用户权限）"""
    if current_user.is_admin:
        # 管理员可以看到所有文件
        sessions = SingleFileSession.query.all()
    else:
        # 普通用户只能看到自己相关的文件
        # 1. 自己上传的文件
        # 2. 通过任务分配的文件
        user_assignments = TaskAssignment.query.filter_by(user_id=current_user.id).all()
        assigned_file_paths = [assignment.task.file_path for assignment in user_assignments if assignment.task and assignment.task.file_path]
        
        sessions = SingleFileSession.query.filter(
            SingleFileSession.file_path.in_(assigned_file_paths)
        ).all()
    
    files_data = []
    for session in sessions:
        file_info = session.to_dict()
        
        # 添加删除权限信息
        can_delete, reason = check_delete_permission(current_user, session)
        file_info['can_delete'] = can_delete
        file_info['delete_reason'] = reason
        
        # 添加文件来源信息
        task_assignment = TaskAssignment.query.filter_by(user_id=current_user.id).join(Task).filter(
            Task.file_path == session.file_path
        ).first()
        
        if task_assignment:
            file_info['source'] = 'task_assignment'
            file_info['task_id'] = task_assignment.task_id
        else:
            file_info['source'] = 'user_upload'
        
        files_data.append(file_info)
    
    return jsonify({
        'success': True,
        'data': {
            'files': files_data
        }
    })

@file_management_bp.route('/files/<session_id>/info', methods=['GET'])
@login_required
def get_file_info(current_user, session_id):
    """获取文件详细信息"""
    session = SingleFileSession.query.get(session_id)
    if not session:
        return jsonify({
            'success': False,
            'error': {
                'code': 'SESSION_NOT_FOUND',
                'message': '文件会话不存在'
            }
        }), 404
    
    # 检查访问权限
    if not current_user.is_admin:
        # 检查是否是通过任务分配的文件
        task_assignment = TaskAssignment.query.filter_by(user_id=current_user.id).join(Task).filter(
            Task.file_path == session.file_path
        ).first()
        
        if not task_assignment:
            return jsonify({
                'success': False,
                'error': {
                    'code': 'ACCESS_DENIED',
                    'message': '没有访问权限'
                }
            }), 403
    
    file_info = session.to_dict()
    
    # 添加权限信息
    can_delete, reason = check_delete_permission(current_user, session)
    file_info['can_delete'] = can_delete
    file_info['delete_reason'] = reason
    
    return jsonify({
        'success': True,
        'data': {
            'file': file_info
        }
    })

