import jwt
import uuid
from datetime import datetime, timedelta
from functools import wraps
from flask import request, jsonify, current_app, Blueprint
from src.models import db
from src.models.user import User
from src.config import Config

# 创建蓝图
auth_bp = Blueprint('auth', __name__)

class AuthManager:
    @staticmethod
    def generate_session_token(user_id):
        """生成会话令牌"""
        payload = {
            'user_id': user_id,
            'exp': datetime.utcnow() + Config.SESSION_TIMEOUT,
            'iat': datetime.utcnow(),
            'jti': str(uuid.uuid4())  # JWT ID
        }
        
        token = jwt.encode(payload, current_app.config['SECRET_KEY'], algorithm='HS256')
        return token
    
    @staticmethod
    def verify_session_token(token):
        """验证会话令牌"""
        try:
            payload = jwt.decode(token, current_app.config['SECRET_KEY'], algorithms=['HS256'])
            user_id = payload['user_id']
            return user_id
        except jwt.ExpiredSignatureError:
            return None
        except jwt.InvalidTokenError:
            return None

def login_required(f):
    """登录验证装饰器"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        auth_header = request.headers.get('Authorization')
        if not auth_header or not auth_header.startswith('Bearer '):
            return jsonify({
                'success': False,
                'error': {
                    'code': 'UNAUTHORIZED',
                    'message': '需要登录'
                }
            }), 401
        
        token = auth_header.split(' ')[1]
        user_id = AuthManager.verify_session_token(token)
        
        if not user_id:
            return jsonify({
                'success': False,
                'error': {
                    'code': 'INVALID_TOKEN',
                    'message': '无效的会话令牌'
                }
            }), 401
        
        user = User.query.get(user_id)
        if not user:
            return jsonify({
                'success': False,
                'error': {
                    'code': 'USER_NOT_FOUND',
                    'message': '用户不存在'
                }
            }), 404
        
        # 将用户信息添加到请求上下文
        request.current_user = user
        
        return f(*args, **kwargs)
    
    return decorated_function

def optional_login(f):
    """可选登录装饰器（支持访客模式）"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        auth_header = request.headers.get('Authorization')
        request.current_user = None
        
        if auth_header and auth_header.startswith('Bearer '):
            token = auth_header.split(' ')[1]
            user_id = AuthManager.verify_session_token(token)
            
            if user_id:
                user = User.query.get(user_id)
                if user:
                    request.current_user = user
        
        return f(*args, **kwargs)
    
    return decorated_function

@auth_bp.route('/login', methods=['POST'])
def login():
    """用户登录"""
    data = request.get_json()
    
    if not data or 'user_id' not in data:
        return jsonify({
            'success': False,
            'error': {
                'code': 'INVALID_REQUEST',
                'message': '缺少用户ID'
            }
        }), 400
    
    user = User.query.get(data['user_id'])
    if not user:
        return jsonify({
            'success': False,
            'error': {
                'code': 'USER_NOT_FOUND',
                'message': '用户不存在'
            }
        }), 404
    
    token = AuthManager.generate_session_token(user.id)
    
    return jsonify({
        'success': True,
        'data': {
            'token': token,
            'user': user.to_dict()
        }
    })

@auth_bp.route('/logout', methods=['POST'])
@login_required
def logout():
    """用户登出"""
    return jsonify({
        'success': True,
        'message': '登出成功'
    })

@auth_bp.route('/me', methods=['GET'])
@login_required
def get_current_user():
    """获取当前用户信息"""
    return jsonify({
        'success': True,
        'data': {
            'user': request.current_user.to_dict()
        }
    })

@auth_bp.route('/users', methods=['GET'])
def get_users():
    """获取所有用户列表"""
    users = User.query.all()
    return jsonify({
        'success': True,
        'data': {
            'users': [user.to_dict() for user in users]
        }
    })

