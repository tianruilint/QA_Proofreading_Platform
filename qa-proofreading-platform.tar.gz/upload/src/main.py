import os
import sys
# DON'T CHANGE THIS !!!
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from flask import Flask, send_from_directory
from flask_cors import CORS
from src.config import Config
from src.models import db
from src.models.user import User
from src.models.task import Task, TaskAssignment
from src.models.single_file import SingleFileSession
from src.models.qa_pair import QAPair
from src.routes.auth import auth_bp
from src.routes.single_file import single_file_bp
from src.routes.collaboration import collaboration_bp
from src.routes.user_groups import user_groups_bp
from src.routes.tasks import tasks_bp
from src.routes.file_management import file_management_bp
from src.routes.traceability import traceability_bp

# 设置静态文件目录为构建后的前端文件目录
static_folder = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'src', 'static')
app = Flask(__name__, static_folder=static_folder, static_url_path='')
app.config.from_object(Config)

# 启用CORS
CORS(app, origins=Config.CORS_ORIGINS)

# 注册蓝图
app.register_blueprint(auth_bp, url_prefix='/api/v1')
app.register_blueprint(single_file_bp, url_prefix='/api/v1')
app.register_blueprint(collaboration_bp, url_prefix='/api/v1')
app.register_blueprint(user_groups_bp, url_prefix='/api/v1')
app.register_blueprint(tasks_bp, url_prefix='/api/v1')
app.register_blueprint(file_management_bp, url_prefix='/api/v1')
app.register_blueprint(traceability_bp, url_prefix='/api/v1')

# 初始化数据库
db.init_app(app)

# 创建上传和导出目录
os.makedirs(Config.UPLOAD_FOLDER, exist_ok=True)
os.makedirs(Config.EXPORT_FOLDER, exist_ok=True)

@app.route('/', defaults={'path': ''})
@app.route('/<path:path>')
def serve(path):
    """服务前端文件和SPA路由回退"""
    # 如果是API请求，返回404
    if path.startswith('api/'):
        return {'success': False, 'error': {'code': 'NOT_FOUND', 'message': '请求的API不存在'}}, 404
    
    # 检查静态文件是否存在
    if path and os.path.exists(os.path.join(app.static_folder, path)):
        return send_from_directory(app.static_folder, path)
    
    # 对于所有其他请求，返回index.html（SPA路由回退）
    index_path = os.path.join(app.static_folder, 'index.html')
    if os.path.exists(index_path):
        return send_from_directory(app.static_folder, 'index.html')
    else:
        return "前端文件未找到，请先构建前端项目", 404

@app.errorhandler(404)
def not_found(error):
    """404错误处理"""
    return {
        'success': False,
        'error': {
            'code': 'NOT_FOUND',
            'message': '请求的资源不存在'
        }
    }, 404

@app.errorhandler(500)
def internal_error(error):
    """500错误处理"""
    return {
        'success': False,
        'error': {
            'code': 'INTERNAL_ERROR',
            'message': '服务器内部错误'
        }
    }, 500

with app.app_context():
    """创建数据库表"""
    db.create_all()

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5001, debug=True)

