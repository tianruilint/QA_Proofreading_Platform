import os
from datetime import timedelta

class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'asdf#FGSgvasgf$5$WGT'
    
    # PostgreSQL配置
    POSTGRES_HOST = os.environ.get('POSTGRES_HOST') or 'localhost'
    POSTGRES_PORT = os.environ.get('POSTGRES_PORT') or '5432'
    POSTGRES_DB = os.environ.get('POSTGRES_DB') or 'qa_proofreading_platform'
    POSTGRES_USER = os.environ.get('POSTGRES_USER') or 'qa_user'
    POSTGRES_PASSWORD = os.environ.get('POSTGRES_PASSWORD') or 'qa_password'
    
    # SQLite配置 - 用于部署
    SQLALCHEMY_DATABASE_URI = os.environ.get('DATABASE_URL') or 'sqlite:///qa_proofreading.db'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    
    # Redis配置
    REDIS_HOST = os.environ.get('REDIS_HOST') or 'localhost'
    REDIS_PORT = os.environ.get('REDIS_PORT') or 6379
    REDIS_DB = os.environ.get('REDIS_DB') or 0
    
    # 文件上传配置
    UPLOAD_FOLDER = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'uploads')
    EXPORT_FOLDER = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'exports')
    MAX_CONTENT_LENGTH = 100 * 1024 * 1024  # 100MB
    
    # 会话配置
    SESSION_TIMEOUT = timedelta(hours=24)
    
    # 任务配置
    MAX_QA_PAIRS_PER_FILE = 50000
    MAX_PARTICIPANTS_PER_TASK = 20
    DEFAULT_PAGE_SIZE = 20
    MAX_PAGE_SIZE = 100
    
    # CORS配置
    CORS_ORIGINS = ["*"]

